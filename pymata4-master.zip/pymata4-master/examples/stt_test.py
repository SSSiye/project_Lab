# import speech_recognition as sr#(앞에 내용을 sr로 줄여서 쓴다)
# r = sr.Recognizer()
# harvard = sr.AudioFile('test.wav')  #얘를 읽어줌
# with harvard as source:      #source = harbard
#     audio = r.record(source)
#     print(r.recognize_google(audio))

import speech_recognition as sr#(앞에 내용을 sr로 줄여서 쓴다)
r = sr.Recognizer()
harvard = sr.AudioFile('helloEN.wav')  #왜 얘는 안됨?
with harvard as source:      #source = harbard
    audio = r.record(source)
    print(r.recognize_google(audio))