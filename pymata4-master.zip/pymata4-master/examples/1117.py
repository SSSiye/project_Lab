"""정보제어공학 2101069 이시예"""
import thingspeak
import time
import random
import sys
from pymata4 import pymata4

channel_id = 1941442 # put here the ID of the channel you created before
write_key = 'VNQFB8B7MLKAD6EO' 
#
POLL_TIME = 5  # number of seconds between polls

# Callback data indices
CB_PIN_MODE = 0
CB_PIN = 1
CB_VALUE = 2
CB_TIME = 3


def the_callback(data):
    pass
#     if not data[3]:
#         tlist = time.localtime(data[6])
#         ftime = f'{tlist.tm_year}-{tlist.tm_mon:02}-{tlist.tm_mday:02} ' \
#                 f'{tlist.tm_hour:02}:{tlist.tm_min:0}:{tlist.tm_sec:02}'
# 
#         print(f'Pin: {data[1]} DHT Type: {data[2]} Humidity:{data[4]}, '
#               f'Temperature: {data[5]} Timestamp: {ftime}')


def dht(my_board, callback=None):
    my_board.set_pin_mode_dht(4, sensor_type=11, differential=.05, callback=callback)
    changed = False
    channel = thingspeak.Channel(id=channel_id, write_key=write_key)
    while True:
        try:
            time.sleep(POLL_TIME)

            # poll the first dht
            value = board.dht_read(4)

            # format the time string and then print the data
            tlist = time.localtime(value[2])
            ftime = f'{tlist.tm_year}-{tlist.tm_mon:02}-{tlist.tm_mday:02} ' \
                    f'{tlist.tm_hour:02}:{tlist.tm_min:0}:{tlist.tm_sec:02}'
            
            humidity, temperature = value[0], value[1]
       
            response = channel.update({'field1': temperature, 'field2': humidity})
            print(f'poll pin 4: humidity={value[0]} temp={value[1]}')
            
    
           
        except KeyboardInterrupt:
            board.shutdown()
            sys.exit(0)


board = pymata4.Pymata4()

try:
    dht(board, the_callback)
except KeyboardInterrupt:
    board.shutdown()
    sys.exit(0)

