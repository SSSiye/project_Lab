import speech_recognition as sr
from stt_mod import stt
from gtts import gTTS    
    
def SttTts():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Say something!")
        audio = r.listen(source)
    text = r.recognize_google(audio)
    print("You said: " + text)          #영어일때
#        print("You said: " + r.recognize_google(audio, language = "ko-kR"))  #한국말일때
    tts = gTTS(text=text, lang='en')
    tts.save('helloEN.wav')             #음성파일 저장
    
    harvard = sr.AudioFile('test.wav')  #*************************다른 파일은 왜 안됨?***************************************
    with harvard as source:      #source = harbard
        audio = r.record(source)
        print(r.recognize_google(audio))
try:
    SttTts()
#     print("You said: " + r.recognize_google(audio))
#    print("You said: " + r.recognize_google(audio), language = "ko-KR")

except sr.UnknownValueError:
    print("Google Speech Recognition could not understand audio")
except sr.RequestError as e:
    print("Could not request results from Google Speech Recognition service; {0}".format(e))
