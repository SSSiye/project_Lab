import sys
import time
from pymata4 import pymata4

# instantiate pymata4

TONE_PIN=3

def set_tone():
    while True:
        # set a pin's mode for tone operations
        board.set_pin_mode_tone(pin_number = TONE_PIN)

        # specify pin, frequency and duration and play tone
        board.play_tone(TONE_PIN, 1000, 500)
        time.sleep(2)

        # specify pin and frequency and play continuously
        board.play_tone_continuously(TONE_PIN, 2000)
        time.sleep(2)

        # specify pin to turn pin off
        board.play_tone_off(TONE_PIN)
        time.sleep(10)
        # clean up
        board.shutdown()
    

board = pymata4.Pymata4()
set_tone()
board.shutdown()
sys.exit(0)