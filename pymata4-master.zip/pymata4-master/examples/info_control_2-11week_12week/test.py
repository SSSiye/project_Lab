import matplotlib.pyplot as plt
import matplotlib.image as img

img_test = img.imread('greentea_ice_flakes.png')
plt.imshow(img_test)
plt.show()