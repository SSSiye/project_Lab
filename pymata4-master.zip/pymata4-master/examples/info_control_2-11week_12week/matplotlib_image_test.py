"""정보제어공학 2101069 이시예"""
import matplotlib.pyplot as plt
import matplotlib.image as img

img_test1 = img.imread('C:\\archive\cats\cat.4001.jpg')
img_test2 = img.imread('C:\\archive\cats\cat.4002.jpg')
img_test3 = img.imread('C:\\archive\cats\cat.4003.jpg')
img_test4 = img.imread('C:\\archive\cats\cat.4004.jpg')
# plt.imshow(img_test)
# plt.show()

plt.figure(figsize=(10,10))

plt.subplot(221)
plt.imshow(img_test1)

plt.subplot(222)
plt.imshow(img_test2)

plt.subplot(223)
plt.imshow(img_test3)

plt.subplot(224)
plt.imshow(img_test4)

# plt.subplot(223)
# plt.imshow(cat_image)

plt.show()