"""정보제어공학 2101069 이시예"""
import matplotlib.pyplot as plt
import csv
  
x = []
y1 = []
y2 = []
  
with open('write2.csv','r') as csvfile:
    lines = csv.reader(csvfile, delimiter=',')
    for row in lines:
        x.append(row[0])
        y1.append(int(row[1]))
        y2.append(int(row[2]))
  
plt.plot(x, y1, y2, color = 'g', linestyle = 'dashed',
         marker = 'o',label = "Weather Data")
  
plt.xticks(rotation = 25)
plt.xlabel('step')
plt.ylabel('ADC')
plt.title('ADC_Report', fontsize = 20)
plt.grid()
#plt.legend()
plt.show()
