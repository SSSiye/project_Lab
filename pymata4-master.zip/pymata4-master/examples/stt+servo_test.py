import sys
import time
from pymata4 import pymata4
import speech_recognition as sr

def SttServo(my_board, pin):
    
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Say something!")
        audio = r.listen(source)
        print("You said: " + r.recognize_google(audio))
        
    if r.recognize_google(audio)=="hello":     #써보모터 발음 어려우니까 hello로 대체~~^^
        r = sr.Recognizer()
        with sr.Microphone() as source:
            print("Say numbers")
            audio = r.listen(source)
            print("You said: " + r.recognize_google(audio))
            
        my_board.set_pin_mode_servo(pin)
        n = r.recognize_google(audio)     #n에 음성인식받은 숫자 저장
        print (n)
        
        my_board.servo_write(pin, int(n))      #써보모터 n만큼 돌리기
        time.sleep(1)
        print(n+"만큼 돌림^^")


board = pymata4.Pymata4()
try:
    SttServo(board, 5)

except sr.UnknownValueError:
    print("Google Speech Recognition could not understand audio")
except sr.RequestError as e:
    print("Could not request results from Google Speech Recognition service; {0}".format(e))
    
except KeyboardInterrupt:
    board.shutdown()
    sys.exit(0)

