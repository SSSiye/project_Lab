import speech_recognition as sr

def stt():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Say something!")
        audio = r.listen(source)
#        print("You said: " + r.recognize_google(audio))  #영어일때
        print("You said: " + r.recognize_google(audio, language = "ko-kR"))  #한국말일때