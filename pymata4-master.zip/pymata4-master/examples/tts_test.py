from gtts import gTTS

text ="the ministers are not to make their decision"

tts = gTTS(text=text, lang='en')
"""text인자에는 변환할 문자열, lang에는 언어를 지정한다.
    en은 영어(여자) ko는 한국어(남자)"""

tts.save('helloEN.wav')


# from gtts import gTTS
# text = "i love Korea"
# tts_en = gTTS(text=text, lang='en')
# tts_kr = gTTS(text='안녕하세요',lang='ko')
# 
# tempFileName = "testFile.mp3" #파일이름 생성+저장
# f = open("testFile.mp3",'wb')   #만든 파일 열어서 밑에 내용 저장
# 
# tts_en.write_to_fp(f)    # 영어로 두번 말하고
# tts_en.write_to_fp(f)
# 
# tts_kr.write_to_fp(f)    # 한글로 한번 말하기
# f.close()                     #파일 닫기