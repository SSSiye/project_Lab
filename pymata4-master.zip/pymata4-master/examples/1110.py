"""정보제어공학 2101069 이시예"""
import sys
import time
import playsound
from playsound import playsound
from pymata4 import pymata4
from gtts import gTTS

#board = pymata4.Pymata4()
#TONE_PIN = 13

buzeron = gTTS(text = '부저를 3초간 동작시킵니다.', lang = 'ko')
buzeroff = gTTS(text = '부저를 3초간 동작했습니다.', lang = 'ko')

buzeron.save('buzeron.mp3')
buzeroff.save('buzeroff.mp3')

playon = ('C:/pymata4-master/examples/buzeron.mp3')

playsound(playon)

for i in range(3):
    print(i + 1)
    time.sleep(1)

playoff = ('C:/pymata4-master/examples/buzeroff.mp3')
playsound(playoff)
#board.shutdown()
sys.exit(0)